
// --- Typewriter Effect ---
const roles = [
    "Cybersecurity Researcher", 
    "Cloud Engineer", 
    "Application Developer",
    "Bug Hunter"
];

let roleIndex = 0;
let charIndex = 0;
let isDeleting = false;
const typewriterElement = document.getElementById("typewriter");

function typeWriter() {
    const currentRole = roles[roleIndex];
    
    if (isDeleting) {
        charIndex--;
    } else {
        charIndex++;
    }

    typewriterElement.textContent = currentRole.substring(0, charIndex);

    // Kecepatan ketik
    let typeSpeed = isDeleting ? 40 : 80;

    if (!isDeleting && charIndex === currentRole.length) {
        typeSpeed = 2000; // Jeda setelah kata selesai
        isDeleting = true;
    } else if (isDeleting && charIndex === 0) {
        isDeleting = false;
        roleIndex = (roleIndex + 1) % roles.length;
        typeSpeed = 500; // Jeda sebelum mengetik kata baru
    }

    setTimeout(typeWriter, typeSpeed);
}

// Mulai typewriter setelah halaman dimuat
document.addEventListener("DOMContentLoaded", () => {
    if(roles.length) setTimeout(typeWriter, 1000);
});

// --- Scroll Reveal Animation ---
function reveal() {
    var reveals = document.querySelectorAll(".reveal");
    for (var i = 0; i < reveals.length; i++) {
        var windowHeight = window.innerHeight;
        var elementTop = reveals[i].getBoundingClientRect().top;
        var elementVisible = 120; // Jarak dari bawah layar untuk memicu animasi

        if (elementTop < windowHeight - elementVisible) {
            reveals[i].classList.add("active");
        }
    }
}

window.addEventListener("scroll", reveal);
reveal(); // Trigger saat pertama diload

// --- Navbar efek Blur/Shadow saat di-scroll ---
window.addEventListener("scroll", () => {
    const navbar = document.getElementById("navbar");
    if (window.scrollY > 50) {
        navbar.style.background = "rgba(13, 17, 23, 0.95)";
        navbar.style.boxShadow = "0 4px 20px rgba(0, 0, 0, 0.4)";
    } else {
        navbar.style.background = "rgba(13, 17, 23, 0.8)";
        navbar.style.boxShadow = "none";
    }
});
